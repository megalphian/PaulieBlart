# Modified by Brian Cho
# Last Modified As: 03/17/2018 1:22
# run.py file is to create local port to run to get a message from other to twilio account.
# required library installed: flask, twilio, pip, virtualenv
# required setup: ngrok (command: ./ngrok <port#>)
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse

app = Flask(__name__)

# application route through twilio (update twilio/Message comes in: https:~/sms created by ngrok on command)
@app.route("/sms", methods=['GET', 'POST'])

# Reply function
def sms_reply():
    # Show text message
    # See detailed segments by deleting ["Body"]

    data = request.values["Body"]
    print(data)

    # Implementation for sfHacks goes here...
    #

    # Add a message to reply
    resp = MessagingResponse()
    resp.message("Thanks so much for your message.")

    return str(resp)

if __name__ == "__main__":
    app.run(debug=True)

'''
data = request.values
Binary input: 1 (from robot to twilio)
***Result shown below***
SFHacks__>> check for data by Body if it is 0 or 1, then return else~
CombinedMultiDict
([
    ImmutableMultiDict([]), 
    ImmutableMultiDict([
        ('ToCountry', 'US'), 
        ('ToState', 'CA'), 
        ('SmsMessageSid', 'SM0105bf975f4d02c1f1e0caba35f5b838'), 
        ('NumMedia', '0'), 
        ('ToCity', ''), 
        ('FromZip', '92870'), 
        ('SmsSid', 'SM0105bf975f4d02c1f1e0caba35f5b838'), 
        ('FromState', 'CA'), 
        ('SmsStatus', 'received'), 
        ('FromCity', 'ANAHEIM'), 
        ('Body', '1'), 
        ('FromCountry', 'US'), 
        ('To', '+19097570441'), 
        ('ToZip', ''), 
        ('NumSegments', '1'), 
        ('MessageSid', 'SM0105bf975f4d02c1f1e0caba35f5b838'), 
        ('AccountSid', 'AC80f6c0e127a3d4e2f190077fea35962e'), 
        ('From', '+17143357534'), 
        ('ApiVersion', '2010-04-01')
    ])
])
'''